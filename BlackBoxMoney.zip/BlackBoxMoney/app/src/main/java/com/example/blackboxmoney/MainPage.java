package com.example.blackboxmoney;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        findViewById(R.id.Trans).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText in = (EditText) findViewById(R.id.Trans_in);
                Integer ta = Integer.parseInt(in.getText().toString());
                transferMoney(ta);
            }
        });
    }

    public void transferMoney (Integer transferAccount) {

    }
}
